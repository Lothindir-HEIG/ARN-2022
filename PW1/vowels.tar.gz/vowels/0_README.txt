Original website: http://www.utdallas.edu/~assmann/KIDVOW/
Peter Assmann, Professor in the School of Behavioral and Brain Sciences at the University of Texas at Dallas

Sound source (category):

namXXXX.wav : natural adult male
samXXXX.wav : synthesized adult male
nafXXXX.wav : natural adult female
safXXXX.wav : synthesized adult female
nkXXXXX.wav : natural kid
skXXXXX.wav : synthesized kid

